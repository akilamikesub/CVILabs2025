#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 23 17:57:50 2024

@author: s.montero@bham.ac.uk
"""

# Import necessary libraries
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

# Step 1: Load the MNIST dataset
# The dataset will be downloaded automatically if not available locally
transform = transforms.Compose([
    transforms.ToTensor(),   # Convert to tensor
    transforms.Normalize((0.5,), (0.5,))  # Normalize to [-1, 1] range
])

# Download the MNIST dataset (training set)
mnist_data = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
dataloader = DataLoader(mnist_data, batch_size=1, shuffle=True)

# Step 2: Visualize a sample image from the MNIST dataset
# Get a single image and label from the dataset
image, label = next(iter(dataloader))

# Display the image
plt.imshow(image.squeeze(0).squeeze(0), cmap='gray')
plt.title(f"MNIST Image - Label: {label.item()}")
plt.show()

# Step 3: Define the Saliency Model (Edge detection using Sobel filter)
class SaliencyModel(nn.Module):
    def __init__(self):
        super(SaliencyModel, self).__init__()
        # Define a simple convolutional layer with a Sobel filter for edge detection
        self.conv = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=False)
        sobel_filter = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32)
        sobel_filter = sobel_filter.unsqueeze(0).unsqueeze(0)  # Reshape for conv layer
        self.conv.weight.data = sobel_filter

    def forward(self, x):
        # Apply convolution
        return self.conv(x)

# Step 4: Create the model and apply it to the MNIST image
model = SaliencyModel()

# Apply the saliency model to the image
saliency_map = model(image)

# Step 5: Visualize the saliency map
saliency_map = saliency_map.squeeze(0).squeeze(0).detach().numpy()  # Remove batch and channel dimensions
plt.imshow(saliency_map, cmap='hot')
plt.title("Saliency Map")
plt.show()

# Step 6: Normalize the saliency map for better visualization
saliency_map = (saliency_map - saliency_map.min()) / (saliency_map.max() - saliency_map.min())
plt.imshow(saliency_map, cmap='hot')
plt.title("Normalized Saliency Map")
plt.colorbar()
plt.show()
